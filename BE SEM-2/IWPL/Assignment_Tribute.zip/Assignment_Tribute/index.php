<?php
	session_start();
	if(isset($_SESSION['username'])):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;1,100&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="style.css">
    <title>Tribute Page</title>
</head>

<body>
	<body>

		<div class="container">
			
			<nav>
				<div class="logo">
					<a href="index.php">Tribute Site</a>
				</div>

				<div class="links">
					<a href="#">Sports</a> 
					<a href="#">Artists</a> 
					<a href="#">Icons</a>
					<a href="#">Titans</a>
					<a><?php
						echo "Hello ".$_SESSION['username'];
					?></a>
					<a href="logout.php">Logout</a>
				</div>
			</nav>

			<div class="main-content">
				<div class="card">
					<div class="card-image">
						<img src="img/greta-thunberg.jpg" alt="Greta Thunberg">
					</div>
					<div class="card-body">
						<div class="card-title">
							<strong>Greta Thunberg</strong>
						</div>
						<p class="content">
							The civil rights movement leaders of the 1960s had no idea that school-shooting survivors from one of the most southern points in the U.S. would lean on their teachings to power a modern nonviolent movement to end gun violence.
							Students around the world began standing up for their survival, leaning only on the fire inside them to prevent the pain they understand too intimately.
						</p>
						<div class="card-action">
							<a href="greta.html">Read More</a>	
						</div>
					</div>
				</div>
			
				<div class="card">
					<div class="card-image">
						<img src="img/jair-bolsonaro.jpg" alt="Jair Bolsonaro">
					</div>
					<div class="card-body">
						<div class="card-title">
							<strong>Jair Bolsonaro</strong>
						</div>
						<p class="content">
							Jair Bolsonaro is a complex character. After three months as Brazil’s President,
                 he represents a sharp break with a decade of high-level corruption, and Brazil’s best chance in a
                  generation to enact economic reforms that can tame rising debt. The former army officer is also a
                   poster boy for toxic masculinity, an ultraconservative homophobe intent on waging.... 
						</p>
						<div class="card-action">
							<a href="jair.html">Read More</a>	
						</div>
					</div>
				</div>
			</div>

			<div class="main-content">
				<div class="card">
					<div class="card-image">
						<img src="img/Lester-Jacinda-Ardern.jpg" alt="Lester Jacinda Ardern">
					</div>
					<div class="card-body">
						<div class="card-title">
							<strong>Lester Jacinda Ardern</strong>
						</div>
						<p class="content">
							Londoners were heartbroken to wake up to news of the horrific terror attack in Christchurch, shocked by
							the callous targeting of innocent civilians for no reason other than their faith.
							Jacinda Ardern’s leadership since the attack has been an inspiration to us all. Not only is she delivering such
                 swift action on gun control, she has sent a powerful message around the world about our shared values—that those
				 who seek to divide us.
						</p>
						<div class="card-action">
							<a href="lester.html">Read More</a>	
						</div>
					</div>
				</div>
			
				<div class="card">
					<div class="card-image">
						<img src="img/william.jpg" alt="William">
					</div>
					<div class="card-body">
						<div class="card-title">
							<strong>William</strong>
						</div>
						<p class="content">
							The civil rights movement leaders of the 1960s had no idea that school-shooting survivors from one of the most southern points in the U.S. would lean on their teachings to power a modern nonviolent movement to end gun violence.
							Students around the world began standing up for their survival, leaning only on the fire inside them to prevent the pain they understand too intimately.
						</p>
						<div class="card-action">
							<a href="william.html">Read More</a>	
						</div>
					</div>
				</div>
			</div>

		</div>
	</body>
</html>

<?php
	else:
		header('Location: login.php');
	endif;
?>
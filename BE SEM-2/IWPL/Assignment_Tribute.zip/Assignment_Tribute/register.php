<?php
	session_start();
	if(!isset($_SESSION['username'])):
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;1,100&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="login_style.css">
    <title>Tribute Page</title>
</head>

<body>
	<body>

		<div class="container">
			<nav>
				<div class="logo">
					<a href="index.php">Tribute Site</a>
				</div>

				<div class="links">
					<a href="#">Sports</a> 
					<a href="#">Artists</a> 
					<a href="#">Icons</a>
					<a href="#">Titans</a>
					<a href="login.php">Login</a>
					<a href="register.php">Register</a>
				</div>
			</nav>
		</div>

		<main class="main-content">
			<div class="form-section">
				<form id="input-form" action="./authController.php" method="post">
					<h4>Sign up to</h4>
					<h1>Tributes</h1>
					<?php
						if(isset($_SESSION['error'])):
					?>
					<p class="form-error" style="display:block !important;"> 
						<?php
							echo $_SESSION['error'];
						?>
					</p>
					<?php
						endif;
					?>
					<div class="field">
						<label for="user_name">User name:</label>
						<input type="text" id="user_name" name="user_name" autocomplete="off" placeholder="Eg: John" autofocus>
						<p class="error user-name-error" id="u-error"></p>
					</div>
					
					<div class="field">
						<label for="name">Name:</label>
						<input type="text" id="name" name="name" autocomplete="off">
						<p class="error name-error" id="n-error"></p>
					</div>
					
					<div class="field">
						<label for="mail">E-mail:</label>
						<input type="email" id="mail" name="user_email" placeholder="example@gmail.com" autocomplete="off">
						<p class="error email-error" id="mail-error"></p>
					</div>

					<div class="field">
						<label for="password">Password:</label>
						<input type="password" id="passwd1" name="passwd1" placeholder="********">
						<p class="error password1-error" id="p1-error"></p>
					</div>

					<div class="field">
						<label for="password">Re-Enter Password:</label>
						<input type="password" id="passwd2" name="passwd2" placeholder="********">
						<p class="error password2-error" id="p2-error"></p>
					</div>

					<div class="field">
						<label for="date">DoB:</label>
						<input type="date" id="dob" name="dob">
					</div>
					
					<div class="field">
						<button type="submit" name="register-btn">Sign Up</button>
					</div>	
				</form>

				<div class="floater">
					<img src="./img/undraw_mobile_images_rc0q.svg" alt="Sign Up Image">
				</div>
			</div>

			<div class="card">
				<p id = 'card-name'>Name : </p>
				<p id = 'card-user-name'>User Name : </p>
				<p id = 'card-email'>Email : </p>
				<p id = 'card-dob'>Date of Birth : </p>

				<button class="logout">LogOut</button>
			</div>


		</main>
        
		<!-- <script src="./JS/validate.js"></script> -->
	</body>
</html>
<?php
	unset($_SESSION['error']);
	else:
		unset($_SESSION['error']);
		header('Location: index.php');
	endif;
?>
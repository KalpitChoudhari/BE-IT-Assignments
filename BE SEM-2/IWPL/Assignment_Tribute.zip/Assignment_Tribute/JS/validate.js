function get(element) {
    return document.getElementById(element);
}

// References to DOM elements - Input Fields
const user_name = get("user_name");
const _name = get("name");
const mail = get("mail");
const passwd1 = get("passwd1");
const passwd2 = get("passwd2");
const dob = get("dob");
const logout = document.querySelector('.logout');
const form = document.querySelector('.form-section');
const card = document.querySelector('.card');

// Error References
const u_error = get('u-error');
const n_error = get('n-error');
const mail_error = get('mail-error');
const p1 = get('p1-error');
const p2 = get('p2-error');


// Functions to display and remove errors
function displayError(context, message) {
    context.style.display = 'block';
    context.innerHTML = message;
    context.style.color = '#ee2929';
}

function removeError(context, inputField) {
    context.style.display = 'none';
}

function setData(userData) {
    // let data;
    // data = JSON.parse(localStorage.getItem('user_data'));
    // data.push(userData);
    const user = JSON.parse(localStorage.getItem(userData.user_name));
    // console.log(user);
    if(!user) {
        // console.log(user);
        localStorage.setItem(userData.user_name, JSON.stringify(userData));
        return true;
    }
    return false;
    // console.log(JSON.stringify(data));
}

// Event Listeners
document.getElementById("user_name").addEventListener('change', e => {
    
    if(user_name.value.length < 3 || user_name.value.includes(' ')) {
        user_name.style.borderBottom = '1px solid #ee2929';
        user_name.style.width = '100%';
        displayError(u_error, 'Invalid Username');
    }
    else {
        user_name.style.borderBottom = '1px solid rgba(0, 0, 0, 0.23)';
        removeError(u_error, user_name);
    }
})

document.getElementById("name").addEventListener('change', e => {
    
    if(_name.value.length <= 3 || /\d/.test(_name.value)) {
        _name.style.borderBottom = '1px solid #ee2929';
        displayError(n_error, 'Invalid Name');
    }
    else {
        _name.style.borderBottom = '1px solid rgba(0, 0, 0, 0.23)';
        removeError(n_error, _name);
    }
})

document.getElementById("mail").addEventListener('change', e => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(mail.value.length < 3 || !re.test(String(mail.value).toLowerCase())) {
        mail.style.borderBottom = '1px solid #ee2929';
        displayError(mail_error, 'Invalid E-Mail');
    }
    else {
        mail.style.borderBottom = '1px solid rgba(0, 0, 0, 0.23)';
        removeError(mail_error, mail);
    }
})

document.getElementById("passwd1").addEventListener('change', e => {
    
    const alpha = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if(passwd1.value.length < 5 || !alpha.test(passwd1.value)) {
        passwd1.style.borderBottom = '1px solid #ee2929';
        displayError(p1, 'Password is not strong enough');
    }
    else {
        passwd1.style.borderBottom = '1px solid rgba(0, 0, 0, 0.23)';
        removeError(p1, passwd1);
    }
})

document.getElementById("passwd2").addEventListener('change', e => {
    
    if(passwd2.value != passwd1.value) {
        passwd2.style.borderBottom = '1px solid #ee2929';
        displayError(p2, 'Passowrd did not match');
    }
    else {
        passwd2.style.borderBottom = '1px solid rgba(0, 0, 0, 0.23)';
        removeError(p2, passwd2);
    }
})

document.querySelector('.logout').addEventListener('click', e => {
    // e.preventDefault();
    form.style.display = 'flex';
    card.style.display = 'none';

    user_name.value = "";
    _name.value = "";
    mail.value = "";
    passwd1.value = "";
    passwd2.value = "";
    dob.value = "";
})

document.getElementById("input-form").addEventListener('submit', e => {
    // e.preventDefault();

    var data = {
        user_name : user_name.value,
        _name : _name.value,
        mail : mail.value,
        passwd1 : passwd1.value,
        passwd2 : passwd2.value,
        dob : dob.value
    }

    

    if( (user_name.value == '' || _name.value == '' || mail.value == '' || passwd1.value == '' || passwd2.value == '')) {
        document.querySelector('.form-error').textContent = 'Please fill all fields.';
        document.querySelector('.form-error').style.display = 'block';
        return;
    }

    if(!setData(data)) {
        displayError(document.querySelector('.form-error') , 'User already exists');
        document.querySelectorAll('.field input').forEach(input => {
            input.value = '';
        })
        return;
    }
    document.querySelector('.form-error').style.display = 'none';
    
    form.style.display = 'none';
    card.style.display = 'block';

   get('card-name').textContent += _name.value;
   get('card-user-name').textContent += user_name.value;
   get('card-email').textContent += mail.value;
   get('card-dob').textContent += dob.value;

})
function get(element) {
    return document.querySelector(element);
}

const user_name = get('#user_name');
const email = get('#mail');
const password = get('#passwd');

const form_error = get('.form-error');
const mail_error = get('.email-error');
const pass_error = get('.password1-error');


function displayError(context, message) {
    context.style.display = 'block';
    context.innerHTML = message;
    context.style.color = '#ee2929';
}

function removeError(context) {
    context.style.display = 'none';
}

function getData(uesrData) {
    const user = JSON.parse(localStorage.getItem(uesrData));
    if(user)
        return true;
    return false;
}

document.getElementById("input-form").addEventListener('submit', e => {
    // e.preventDefault();

    if(!getData(user_name.value)) {
        displayError(form_error, 'Please Sign up first!');
        user_name.value = "";
        email.value = "";
        password.value = "";
        removeError(mail_error);
        removeError(pass_error);
        user_name.focus();
        return;
    }

    removeError(form_error);
    let userData = JSON.parse(localStorage.getItem(user_name.value));
    if(userData.mail != email.value || userData.passwd1 != password.value) {
        email.style.borderBottom = '1px solid #ee2929';
        email.style.width = '100%';
        displayError(mail_error, 'Email did not matched!');

        password.style.borderBottom = '1px solid #ee2929';
        password.style.width = '100%';
        displayError(pass_error, 'Email did not matched!');
    }

    else {
        removeError(mail_error);
        removeError(pass_error);
        console.log("login success");

        user_name.value = "";
        email.value = "";
        password.value = "";

        location.href = '#';
    }

})
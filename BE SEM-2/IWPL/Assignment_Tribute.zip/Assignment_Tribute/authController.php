<?php
    session_start();
    include "db.php";
    if(isset($_POST['login-btn'])) {        
        $username = $_POST['user_name'];
        $email = $_POST['user_email'];
        $pass = $_POST['passwd'];
        
        if($username == "" || $email == "" || $pass == "") {
            $_SESSION['error'] = "Please fill all fields!";
            header('Location: login.php');
        }
        else {
            
            $sql = "SELECT * FROM users where username='$username' and password='$pass'";
            $result = $db->query($sql);

            if ($result->num_rows > 0) {
                $_SESSION['username'] = $username;
                header('Location: index.php');
            }
            else {
                $_SESSION['error'] = "Invalid Credentials";    
                header('Location: login.php');
            }
            $db->close();
        }
    }

    if(isset($_POST['register-btn'])) {
        $username = $_POST['user_name'];
        $name = $_POST['name'];
        $useremail = $_POST['user_email'];
        $password1 = $_POST['passwd1'];
        $password2 = $_POST['passwd2'];
        $date = $_POST['dob'];

        if($username == "" || $name == "" || $useremail == "" || $password1 == "" || $password2 == "" || $date == "" ) {
            $_SESSION['error'] = "Please fill all the fields!";
            header('Location: register.php');
        }
        else if($password1 != $password2) {
            $_SESSION['error'] = "Password did not matched!";
            header('Location: register.php');
        }
        else {
            $userNames = "SELECT * FROM users where username='$username'";
            $exists = $db->query($userNames);
            if($exists->num_rows > 0) {
                $_SESSION['error'] = "User already exists!";
                header('Location: register.php');
                exit();
            }

            $sql = "INSERT INTO users VALUES ('$username', '$useremail', '$password1')";
            $result = $db->query($sql);
            echo $result;
            if ($result === TRUE) {
                header('Location: login.php');
            }
            else {
                $_SESSION['error'] = "Something went wrong! Try again after some time.";
                header('Location: register.php');
            }
            $db->close();
        }
    }

?>